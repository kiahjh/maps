import { waterways } from '../data/terrain';
import type { Landscape, Point } from '../types';

import { fractal, noise, smooth } from './terrain-math';
import { cataract, cataractGround } from './cataract';
export { fractal, hash, noise, smooth } from './terrain-math';
// One local unit is a metre; regional positions remain schematic until rebuilt.
export const fork = { x: 890, y: 587 };

// Sample the canonical cubic SVG paths as world geometry; rendering no longer
// draws them as SVG strokes. S reflects the preceding control point.
export function samplePath(path: string, steps = 28): Point[] {
  const tokens = path.match(/[MCS]|-?\d+(?:\.\d+)?/g)!;
  let index = 0, current = { x: 0, y: 0 }, control = current;
  const points: Point[] = [];
  const point = () => ({ x: Number(tokens[index++]), y: Number(tokens[index++]) });
  while (index < tokens.length) {
    const command = tokens[index++];
    if (command === 'M') { current = point(); control = current; points.push(current); continue; }
    const a = current;
    const b = command === 'S' ? { x: a.x * 2 - control.x, y: a.y * 2 - control.y } : point();
    const c = point(), d = point();
    for (let i = 1; i <= steps; i++) {
      const t = i / steps, s = 1 - t;
      points.push({ x: s ** 3 * a.x + 3 * s * s * t * b.x + 3 * s * t * t * c.x + t ** 3 * d.x,
        y: s ** 3 * a.y + 3 * s * s * t * b.y + 3 * s * t * t * c.y + t ** 3 * d.y });
    }
    current = d; control = c;
  }
  return points;
}
export interface River { id: string; points: Point[]; width: number; alwaysWet?: boolean; upper?: boolean }
export const rivers: River[] = [
  { id: 'upper', points: [{ x: 1120, y: -450 }, { x: 1110, y: -280 }, { x: 1080, y: -80 }, ...samplePath(waterways.upper)], width: cataract.upstreamWidth / 2, upper: true },
  { id: 'first', points: samplePath(waterways.first), width: cataract.westWidth / 2 },
  { id: 'second', points: samplePath(waterways.second), width: cataract.eastWidth / 2 },
  { id: 'hot', points: samplePath(waterways.hot), width: 1.8, alwaysWet: true },
];
export function riverWidthAt(river: River, y: number) {
  const mouth = river.id === 'first' || river.id === 'second' ? 1 - smooth(587, 650, y) : 0;
  return river.width * (1 - mouth) + cataract.upstreamWidth / 2 * mouth;
}
interface Segment { a: Point; dx: number; dy: number; lengthSquared: number; river: River }
const segments: Segment[] = rivers.flatMap(river => river.points.slice(1).map((b, i) => {
  const a = river.points[i], dx = b.x - a.x, dy = b.y - a.y;
  return { a, dx, dy, lengthSquared: dx * dx + dy * dy, river };
}));
// Only nearby channel segments affect erosion or vegetation. Index their
// influence bounds so generating the terrain doesn't block on every river.
const cellSize = 100, influence = 220;
const riverCells = new Map<string, Segment[]>();
for (const segment of segments) {
  const bx = segment.a.x + segment.dx, by = segment.a.y + segment.dy;
  for (let y = Math.floor((Math.min(segment.a.y, by) - influence) / cellSize); y <= Math.floor((Math.max(segment.a.y, by) + influence) / cellSize); y++) {
    for (let x = Math.floor((Math.min(segment.a.x, bx) - influence) / cellSize); x <= Math.floor((Math.max(segment.a.x, bx) + influence) / cellSize); x++) {
      const key = `${x},${y}`, cell = riverCells.get(key) ?? [];
      cell.push(segment); riverCells.set(key, cell);
    }
  }
}
export function nearestRiver(x: number, y: number) {
  let squared = Infinity, river = rivers[0], channelY = y;
  for (const segment of riverCells.get(`${Math.floor(x / cellSize)},${Math.floor(y / cellSize)}`) ?? []) {
    const dx = x - segment.a.x, dy = y - segment.a.y;
    const t = Math.max(0, Math.min(1, (dx * segment.dx + dy * segment.dy) / segment.lengthSquared));
    const d = (dx - t * segment.dx) ** 2 + (dy - t * segment.dy) ** 2;
    if (d < squared) { squared = d; river = segment.river; channelY = segment.a.y + t * segment.dy; }
  }
  return { distance: Math.sqrt(squared), river, channelY, halfWidth: riverWidthAt(river, channelY) };
}
// The first detail pass is feathered into the existing world around the falls.
export function cataractZone(x: number, y: number) {
  return 1 - smooth(.55, 1, Math.hypot((x - fork.x) / 310, (y - 620) / 260));
}
export const scarpLine = (x: number) => {
  const local = 1 - smooth(180, 320, Math.abs(x - fork.x));
  const recess = (noise(x / 38, 4) - noise(fork.x / 38, 4)) * 43;
  return 594 + 13 * Math.sin((x - fork.x) / 90) + 4 * Math.sin((x - fork.x) / 18)
    + .00014 * (x - fork.x) ** 2 + local * recess;
};
function ellipse(x: number, y: number, cx: number, cy: number, rx: number, ry: number) {
  return Math.hypot((x - cx) / rx, (y - cy) / ry);
}
export function woodland(x: number, y: number) {
  const edge = (noise(x / 42, y / 42) - .5) * .24;
  const evil = 1 - smooth(.78, 1.08, ellipse(x, y, 825, 1130, 132, 174) + edge);
  const eastern = 1 - smooth(.65, 1.12, ellipse(x, y, 1455, 1085, 303, 421) + edge);
  const pine = 1 - smooth(.68, 1.05, ellipse(x, y, 265, 600, 145, 120) + edge);
  return { evil, forest: Math.max(evil, eastern, pine) };
}
export function terrainSample(x: number, y: number) {
  const nearest = nearestRiver(x, y), d = nearest.distance, width = nearest.halfWidth;
  const line = scarpLine(x), local = cataractZone(x, y);
  const originalPlateau = 1 - smooth(line - 7, line + 17, y);
  // Unequal shelves, recessed faces and a rubble apron replace the single ramp.
  const ledge = (noise(x / 24, 9) - .5) * 9;
  const shelves = .55 * (1 - smooth(line - 12 + ledge, line + 1 + ledge, y))
    + .29 * (1 - smooth(line + 8 - ledge, line + 21 - ledge, y))
    + .16 * (1 - smooth(line + 33, line + 58, y));
  const plateau = originalPlateau * (1 - local) + shelves * local;
  const scarp = Math.exp(-(((x - 890) / 480) ** 4));
  const broad = fractal(x / 110, y / 110), detail = fractal(x / 28, y / 28);
  const valley = Math.exp(-((d / 75) ** 2));
  const channel = 1 - smooth(width * .55, width * 1.7, d);
  const carved = channel * 12 + valley * 9;
  const ridge = Math.pow(Math.abs(noise(x / 66, y / 90) - .5) * 2, 2) * 38;
  const ravines = smooth(640, 720, y) * (1 - smooth(950, 1050, y)) * Math.exp(-(((x - 850) / 260) ** 2));
  const face = (1 - smooth(48, 90, Math.abs(y - line))) * local;
  const relief = (noise(x / 5.5, y / 9) - .5) * 3.5 * face;
  const originalTalus = local * Math.exp(-(((y - line - 68) / 30) ** 2));
  const originalMoss = local * (1 - smooth(20, 65, Math.abs(y - line - 62)))
    * (.35 + noise(x / 13, y / 17) * .65) * (1 - smooth(5, 24, d));
  const originalHeight = relief + originalTalus * (4 + noise(x / 15, y / 11) * 7) + 28 + (1500 - y) * .017 + (broad - .5) * 31 + (detail - .5) * 8
    + originalPlateau * scarp * 38 + ravines * ridge - carved;
  const close = cataractGround(x, y, d, width, nearest.channelY);
  const height = originalHeight * (1 - local) + close.height * local;
  const sandFill = (nearest.river.upper ? carved * plateau : 0) * (1 - local) + close.sandFill * local;
  const wood = woodland(x, y);
  const sand = plateau * scarp;
  const bank = Math.exp(-(((d - width - 10) / 35) ** 2));
  const regrowth = Math.max(sand * .8, bank * .9);
  const originalCliff = (1 - smooth(13, 43 + local * 35, Math.abs(y - line - local * 10))) * scarp;
  const cliff = originalCliff * (1 - local) + close.cliff * local;
  const talus = originalTalus * (1 - local) + close.talus * local;
  const moss = originalMoss * (1 - local) + close.moss * local;
  return { height, sandFill, sand, bank, channel, valley, cliff, local, talus, moss, ...wood, regrowth, distance: d, river: nearest.river, broad, detail, plateau };
}
export function elevationAt(x: number, y: number, landscape: Landscape = 'restored') {
  const sample = terrainSample(x, y);
  return sample.height + (landscape === 'dry' ? sample.sandFill : 0);
}
